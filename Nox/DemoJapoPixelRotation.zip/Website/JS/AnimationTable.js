var images = [
["bat_fly", 11, "Bat [Fly]"], 	// Simple
["bunny_shake_ear", 11, "Bunny [Shake Ear]"], // Easy
["clairvowl_flap_wings", 11, "Clairvowl [Flap Wings]"], // Easy
["dog_2_shake_hand", 17, "Dog [Shake Hand]"], // Hard
["dog_3_walk", 31, "Dog [Walk]"], // Hard
["dog_sit", 19, "Dog [Sit]"], // Easy
["dove_fly", 11, "Dove [Fly]"], // Simple
["elephant_shake_noise", 25, "Elephant [Shake Noise]"], // Simple
["flower_wind_flowing", 21, "Flower [Wind Flowing]"], // Simple
["fox_lie_down", 16, "Fox [Lie Down]"], // Hard
["golem_swing", 15, "Golem [Swing]"], // Simple
["kitten_jump", 10, "Kitten [Jump]"], // Simple
["lizard_move", 13, "Lizard [Move]"], // Easy
["man_lean", 11, "Man [Lean]"], // Hard
["man_walk", 21, "Man [Walk]"], // Hard
["mike_dance", 31, "Mike [Dance]"], // Hard
["mike_walk", 9, "Mike [Walk]"], // Simple
["nappa_attack", 7, "Nappa [Attack]"], // Hard
["nappa_idle", 7, "Nappa [Idle]"], // Simple
["ogremon_attack", 13, "Ogremon [Attack]"], // Simple
["orca_dive", 16, "Orca [Dive]"], // Easy
["saber_rotation", 37, "Saber [Rotation]"], // Simple
["scorpion_shake_tail", 9, "Scorpion [Shake Tail]"], // Easy
["snake_bite", 11, "Snake [Bite]"], // Hard
["snake_twist", 11, "Snake [Twist]"], // Easy
["tanuki_walk", 21, "Tanuki [Walk]"], // Easy
["trainer_throw_ball", 12, "Trainer [Throw Ball]"], // Simple
["whale_2_spin", 37, "Whale [Spin]"], // Easy
["whale_spin", 37, "Whale [Spin]"], // Simple
["wolf_2_jump", 26, "Wolf [Jump]"], //Simple
["wolf_howl", 11, "Wolf [Howl]"] // Easy
];